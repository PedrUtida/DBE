package br.com.fiap;

import javax.faces.bean.ManagedBean;

@ManagedBean
public class IndexBean {
	
	public void executar() {
			System.out.println("Executando comando...");
	}

}
