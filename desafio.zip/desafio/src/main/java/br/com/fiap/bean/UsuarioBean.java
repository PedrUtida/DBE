package br.com.fiap.bean;

import javax.faces.bean.ManagedBean;

import br.com.fiap.model.Usuario;

@ManagedBean
public class UsuarioBean {
	
	private Usuario usuario = new Usuario();
	
	public void save() {
		new UsuarioDAO().save(this.usuario);
		System.out.println(this.usuario);
	}

	public Usuario getSetup() {
		return usuario;
	}

	public void setSetup(Usuario setup) {
		this.usuario = setup;
	}
	
	

}
