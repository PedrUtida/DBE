package br.com.fiap.bean;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


import br.com.fiap.model.Usuario;

public class UsuarioDAO {

	public void save(Usuario usuario) {
		
		EntityManagerFactory factory=
			Persistence.createEntityManagerFactory("CP-persistence-unit");
		
		EntityManager manager = factory.createEntityManager();
		
		manager.getTransaction().begin();
		manager.persist(usuario);
		manager.getTransaction().commit();
		
		manager.clear();
	}

}
